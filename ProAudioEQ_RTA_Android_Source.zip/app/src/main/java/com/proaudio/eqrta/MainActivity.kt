package com.proaudio.eqrta

import android.Manifest
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Bundle
import android.os.Process
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Color
import android.graphics.Typeface
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlin.concurrent.thread
import kotlin.math.*

class MainActivity : ComponentActivity() {
    private var recorder: AudioRecord? = null
    @Volatile private var running = false
    private lateinit var chart: RtaView
    private lateinit var status: TextView
    private val bandNames = listOf("20","25","31.5","40","50","63","80","100","125","160","200","250","315","400","500","630","800","1k","1.25k","1.6k","2k","2.5k","3.15k","4k","5k","6.3k","8k","10k","12.5k","16k","20k")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.setBackgroundColor(Color.rgb(8,11,18))
        buildUi()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun label(s: String, size: Float = 14f, color: Int = Color.WHITE): TextView =
        TextView(this).apply { text=s; textSize=size; setTextColor(color); gravity=Gravity.CENTER_VERTICAL }

    private fun buildUi() {
        val outer = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(12),dp(10),dp(12),dp(10)) }
        val title = label("PRO AUDIO EQ + RTA", 23f, Color.rgb(0,220,255)).apply { typeface=Typeface.DEFAULT_BOLD }
        outer.addView(title, LinearLayout.LayoutParams(-1, dp(42)))
        outer.addView(label("ANDROID • LIVE SOUND • 1/3 OCTAVE", 11f, Color.LTGRAY), LinearLayout.LayoutParams(-1,dp(24)))

        val modeRow = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        val micBtn = Button(this).apply { text="MIC RTA"; setOnClickListener { requestMic() } }
        val infoBtn = Button(this).apply { text="CUBASIS 3"; setOnClickListener {
            AlertDialog.Builder(this@MainActivity).setTitle("ใช้งานกับ Cubasis 3")
                .setMessage("แอปนี้วิเคราะห์เสียงจากไมโครโฟนมือถือได้ ส่วน Android ไม่อนุญาตให้ดึงเสียงจาก Cubasis 3 โดยตรงทั่วไป\\n\\nสำหรับ EQ ในโปรเจกต์ ให้เปิด Cubasis 3 > เลือกแทร็ก > Insert Effects > EQ ของ Cubasis หรือปลั๊กอินที่รองรับ ส่วนแอปนี้ใช้ดู RTA จากไมค์/เสียงลำโพงภายนอกได้")
                .setPositiveButton("เข้าใจแล้ว", null).show()
        } }
        modeRow.addView(micBtn, LinearLayout.LayoutParams(0,dp(50),1f))
        modeRow.addView(infoBtn, LinearLayout.LayoutParams(0,dp(50),1f))
        outer.addView(modeRow)

        status = label("สถานะ: ยังไม่เริ่มวิเคราะห์", 13f, Color.YELLOW)
        outer.addView(status, LinearLayout.LayoutParams(-1,dp(34)))
        chart = RtaView(this)
        outer.addView(chart, LinearLayout.LayoutParams(-1,dp(250)))

        val actions = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        actions.addView(Button(this).apply { text="เริ่ม RTA"; setOnClickListener { requestMic() } }, LinearLayout.LayoutParams(0,dp(48),1f))
        actions.addView(Button(this).apply { text="หยุด"; setOnClickListener { stopRta() } }, LinearLayout.LayoutParams(0,dp(48),1f))
        actions.addView(Button(this).apply { text="รีเซ็ต"; setOnClickListener { chart.clear() } }, LinearLayout.LayoutParams(0,dp(48),1f))
        outer.addView(actions)

        outer.addView(label("31-BAND EQ • ค่าที่ตั้งไว้สำหรับนำไปปรับใน Cubasis 3", 15f, Color.rgb(0,220,255)),
            LinearLayout.LayoutParams(-1,dp(42)))
        outer.addView(label("เลื่อนแถบเพื่อดู/จดค่า Gain (dB) — ไม่ได้ประมวลผลเสียง Cubasis โดยตรง", 11f, Color.LTGRAY),
            LinearLayout.LayoutParams(-1,dp(28)))

        val scroll = ScrollView(this)
        val eqColumn = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        bandNames.forEach { freq ->
            val row = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
            val f = label("$freq Hz", 12f, Color.WHITE)
            val value = label("0.0 dB", 12f, Color.rgb(0,220,255)).apply { gravity=Gravity.CENTER }
            val seek = SeekBar(this).apply {
                max=240; progress=120
                setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) { value.text=String.format("%.1f dB", (p-120)/10.0) }
                    override fun onStartTrackingTouch(sb: SeekBar?) {}
                    override fun onStopTrackingTouch(sb: SeekBar?) {}
                })
            }
            row.addView(f, LinearLayout.LayoutParams(dp(66),dp(42)))
            row.addView(seek, LinearLayout.LayoutParams(0,dp(42),1f))
            row.addView(value, LinearLayout.LayoutParams(dp(64),dp(42)))
            eqColumn.addView(row)
        }
        scroll.addView(eqColumn)
        outer.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        setContentView(outer)
    }

    private fun requestMic() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 10)
        } else startRta()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode==10 && grantResults.isNotEmpty() && grantResults[0]==PackageManager.PERMISSION_GRANTED) startRta()
        else status.text="สถานะ: ไม่ได้รับอนุญาตใช้ไมโครโฟน"
    }

    private fun startRta() {
        stopRta()
        val rate=44100
        val size=2048
        val min=AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (min<=0) { status.text="ไมโครโฟนเริ่มทำงานไม่ได้"; return }
        try {
            recorder=AudioRecord(MediaRecorder.AudioSource.UNPROCESSED, rate, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT, max(min,size*2))
            if (recorder?.state != AudioRecord.STATE_INITIALIZED) {
                recorder?.release(); recorder=AudioRecord(MediaRecorder.AudioSource.MIC,rate,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT,max(min,size*2))
            }
            recorder?.startRecording()
            running=true
            status.text="สถานะ: กำลังวิเคราะห์เสียงจากไมโครโฟน • 44.1 kHz"
            thread(name="RTA-Audio") {
                Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO)
                val buffer=ShortArray(size)
                while(running) {
                    val n=recorder?.read(buffer,0,size) ?: -1
                    if(n==size) {
                        val levels=Spectrum.analyze(buffer,rate)
                        runOnUiThread { if(running) chart.setLevels(levels) }
                    }
                }
            }
        } catch(e: Exception) { status.text="เปิดไมโครโฟนไม่สำเร็จ: ${e.message}" }
    }

    private fun stopRta() {
        running=false
        try { recorder?.stop() } catch(_:Exception) {}
        recorder?.release(); recorder=null
        if(::status.isInitialized) status.text="สถานะ: หยุดวิเคราะห์แล้ว"
    }

    override fun onDestroy() { stopRta(); super.onDestroy() }
}

private object Spectrum {
    private val centers = doubleArrayOf(20.0,25.0,31.5,40.0,50.0,63.0,80.0,100.0,125.0,160.0,200.0,250.0,315.0,400.0,500.0,630.0,800.0,1000.0,1250.0,1600.0,2000.0,2500.0,3150.0,4000.0,5000.0,6300.0,8000.0,10000.0,12500.0,16000.0,20000.0)
    fun analyze(input: ShortArray, sampleRate: Int): FloatArray {
        val n=input.size
        val re=DoubleArray(n); val im=DoubleArray(n)
        for(i in 0 until n) {
            val w=0.5*(1.0-cos(2.0*PI*i/(n-1)))
            re[i]=input[i]/32768.0*w
        }
        var j=0
        for(i in 1 until n) {
            var bit=n shr 1
            while(j and bit != 0) { j=j xor bit; bit=bit shr 1 }
            j=j xor bit
            if(i<j) { val t=re[i]; re[i]=re[j]; re[j]=t }
        }
        var len=2
        while(len<=n) {
            val ang=-2.0*PI/len
            val wr0=cos(ang); val wi0=sin(ang)
            var start=0
            while(start<n) {
                var wr=1.0; var wi=0.0
                for(k in 0 until len/2) {
                    val u=start+k; val v=u+len/2
                    val vr=re[v]*wr-im[v]*wi; val vi=re[v]*wi+im[v]*wr
                    re[v]=re[u]-vr; im[v]=im[u]-vi
                    re[u]+=vr; im[u]+=vi
                    val tmp=wr*wr0-wi*wi0; wi=wr*wi0+wi*wr0; wr=tmp
                }
                start+=len
            }
            len=len shl 1
        }
        return FloatArray(31) { idx ->
            val bin=(centers[idx]*n/sampleRate).roundToInt().coerceIn(1,n/2-1)
            val mag=sqrt(re[bin]*re[bin]+im[bin]*im[bin])/n*4.0
            (20.0*log10(mag+1e-7)).toFloat().coerceIn(-72f,0f)
        }
    }
}

private class RtaView(context: android.content.Context) : View(context) {
    private val paint=android.graphics.Paint(3)
    private var levels=FloatArray(31){-72f}
    private val labels=arrayOf("20","50","100","250","500","1k","2k","5k","10k","20k")
    fun setLevels(v: FloatArray) { levels=v; invalidate() }
    fun clear() { levels=FloatArray(31){-72f}; invalidate() }
    override fun onDraw(canvas: android.graphics.Canvas) {
        super.onDraw(canvas)
        val w=width.toFloat(); val h=height.toFloat()
        canvas.drawColor(Color.rgb(10,15,25))
        val left=dp(34).toFloat(); val right=w-dp(8); val top=dp(12).toFloat(); val bottom=h-dp(30)
        paint.color=Color.rgb(45,60,78); paint.strokeWidth=1f
        for(i in 0..6) {
            val y=top+(bottom-top)*i/6f
            canvas.drawLine(left,y,right,y,paint)
            paint.color=Color.LTGRAY; paint.textSize=dp(10).toFloat()
            canvas.drawText("${-i*12} dB",dp(2).toFloat(),y+dp(4),paint)
            paint.color=Color.rgb(45,60,78)
        }
        for(i in 0..9) {
            val x=left+(right-left)*i/9f
            canvas.drawLine(x,top,x,bottom,paint)
            paint.color=Color.LTGRAY; paint.textSize=dp(9).toFloat()
            canvas.drawText(labels[i],x-dp(10),h-dp(8),paint)
            paint.color=Color.rgb(45,60,78)
        }
        val bw=(right-left)/31f*0.72f
        for(i in levels.indices) {
            val x=left+(right-left)*(i+0.5f)/31f
            val norm=((levels[i]+72f)/72f).coerceIn(0f,1f)
            val y=bottom-(bottom-top)*norm
            paint.shader=android.graphics.LinearGradient(x,bottom,x,y,Color.rgb(0,100,255),Color.rgb(0,255,130),android.graphics.Shader.TileMode.CLAMP)
            canvas.drawRect(x-bw/2,y,x+bw/2,bottom,paint)
            paint.shader=null
        }
        paint.color=Color.WHITE; paint.textSize=dp(12).toFloat(); paint.typeface=Typeface.DEFAULT_BOLD
        canvas.drawText("RTA • 31 BANDS • LIVE MIC INPUT",left,top+dp(1),paint)
    }
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
}
